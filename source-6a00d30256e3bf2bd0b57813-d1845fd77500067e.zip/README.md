# Portal de Pacientes

An interactive patient portal for managing medical consultations and viewing nurse contact information. Built with TanStack Start and deployed on Netlify.

## Tech Stack

- **Framework**: TanStack Start (React 19 + TanStack Router v1)
- **Build Tool**: Vite 7
- **Styling**: Tailwind CSS 4
- **Language**: TypeScript 5.7 (strict mode)
- **Deployment**: Netlify

## Getting Started

Install dependencies and start the dev server:

```bash
npm install
npm run dev
```

The app runs at [http://localhost:3000](http://localhost:3000) (or port 8888 via Netlify CLI).

### With Netlify CLI (recommended)

```bash
netlify dev
```

This emulates Netlify features locally including functions and environment variables.

## Build

```bash
npm run build
```

Output goes to `dist/client/`.
