CREATE TABLE "consultations" (
	"id" serial PRIMARY KEY,
	"patient_name" text NOT NULL,
	"dni" text NOT NULL,
	"consultation_type" text NOT NULL,
	"reason" text NOT NULL,
	"status" text DEFAULT 'pendiente' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
