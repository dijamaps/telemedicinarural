import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const consultations = pgTable("consultations", {
  id: serial().primaryKey(),
  patientName: text("patient_name").notNull(),
  dni: text("dni").notNull(),
  consultationType: text("consultation_type").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pendiente"),
  createdAt: timestamp("created_at").defaultNow(),
});
