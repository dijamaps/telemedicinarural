import { createServerFn } from '@tanstack/react-start'
import { db } from '../../db/index.js'
import { consultations } from '../../db/schema.js'

export const submitConsultation = createServerFn({ method: 'POST' })
  .inputValidator(
    (data: {
      patientName: string
      dni: string
      consultationType: string
      reason: string
    }) => {
      if (!data.patientName || !data.dni || !data.consultationType || !data.reason) {
        throw new Error('Todos los campos son obligatorios')
      }
      return data
    },
  )
  .handler(async ({ data }) => {
    const [consultation] = await db
      .insert(consultations)
      .values({
        patientName: data.patientName,
        dni: data.dni,
        consultationType: data.consultationType,
        reason: data.reason,
      })
      .returning()

    return consultation
  })
