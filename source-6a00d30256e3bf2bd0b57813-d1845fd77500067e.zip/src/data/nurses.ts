export interface Nurse {
  id: number
  name: string
  specialty: string
  phone: string
  whatsapp?: string
  avatar?: string
}

const nurses: Array<Nurse> = [
  {
    id: 1,
    name: 'Maryorit Mercedes Huamacto',
    specialty: 'Enfermera',
    phone: '+51981558141',
    whatsapp: 'https://wa.me/51981558141',
  },
  {
    id: 2,
    name: 'Maryori Barahona',
    specialty: 'Enfermera',
    phone: '+51920244549',
  },
]

export default nurses
